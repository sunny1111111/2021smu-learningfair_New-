print("1단계 가위바위보 게임에 오신것을 환영합니다.")
print("마우스 좌클릭은 '주먹', 휠클릭은 '가위', 우클릭은 '보'입니다.")
print("성공시 다음단계로 넘어가고 실패시 사망하게 됩니다.")

import turtle as t
import random

def com_choice():
    rand_choice = random.randint(0, 2)
    com.shape(images[rand_choice])
    return com_list[rand_choice]

#게임 결과 판정
def result_print(user_c, com_c):
    t.clear()
    t.goto(0, -100)
    if user_c == com_c:
        t.write("무승부", False, "center", ("", 40))
    elif winning_case[user_c] == com_c:
        t.write("승", False, "center", ("", 40))
        vi= t.Turtle()
        vi.up()
        vi.goto(0, 0)
        vi.shape(승리_gif)#승리화면 넣기
    else:
        t.write("패", False, "center", ("", 40))
        en= t.Turtle()
        en.up()
        en.goto(0, 0)
        en.shape(끝_gif)#종료화면 넣기

def rock(x, y):
    user.shape(rock_gif)
    com = com_choice()
    result_print("rock", com) # 승부결과 판정
    
def scissors(x, y):
    user.shape(scissors_gif)
    com = com_choice()
    result_print("scissors", com)

def paper(x, y):
    user.shape(paper_gif)
    com = com_choice()
    result_print("paper", com)


#기본설정
t. bgcolor("DarkCyan")
t.title("1단계 가위바위보 게임")
t.ht()
t.up()

rock_gif = "images/rock.gif"
scissors_gif = "images/scissors.gif"
paper_gif = "images/paper.gif"
t.addshape(rock_gif)
t.addshape(scissors_gif)
t.addshape(paper_gif)

#관리자 캐릭터
세모_gif = "images/세모.gif"
t.addshape(세모_gif)

#게임종료화면
끝_gif = "images/끝.gif"
t.addshape(끝_gif)

#승리화면
승리_gif = "images/승리.gif"
t.addshape(승리_gif)

images = [rock_gif, scissors_gif, paper_gif]
com_list = ["rock", "scissors", "paper"]
winning_case = {"rock" : "scissors", "scissors" : "paper", "paper" : "rock"}

#나의 선택 이미지
user = t.Turtle()
user.up()
user.speed(0)
user.goto(-220, 200)
user.write("YOU", False, "center", ("", 30))
user.goto(-220, -100)
user.shape(rock_gif)

#컴퓨터의 선택 이미지
com= t.Turtle()
com.up()
com.speed(0)
com.goto(220, 200)
com.write("Player456", False, "center", ("", 30))
com.goto(220, -100)
com.shape(rock_gif)

#세모 넣어보기
se= t.Turtle()
se.up()
se.goto(0, 200)
se.shape(세모_gif)

t.onscreenclick(rock, 1) #마우스 좌 클릭
t.onscreenclick(scissors, 2) #마우스 휠 클릭
t.onscreenclick(paper, 3) #마우스 우 클릭

t.done()


