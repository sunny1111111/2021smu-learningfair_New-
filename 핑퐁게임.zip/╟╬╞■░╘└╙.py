import turtle as t
import random
import time

t.bgcolor("darkcyan")
t.ht()   #hide turtle
t.up()
t.write("ping pong game start!!", False, "center",("cooper Black",30))
time.sleep(1.5)
t.clear()

t.setup(500,700)

def right():    #right 함수 생성
    if player.xcor() < 200: #x좌표값이 200보다 작게 : 오른쪽 벽을 지나가지 않도록 조정 
        player.forward(10)  #10씩 이동
def left():    
    if player.xcor() > -200: #x좌표값이 -200보다 크게 : 왼쪽  벽을 지나가지 않도록 조정 
        player.backward(10)  #10씩 이동

def random_pos():
    x_cor = random.randint(-220, 220)
    y_cor = random.randint(-220, 220)
    return x_cor, y_cor



#플레이어 
player = t.Turtle()
player.shape("square")
player.color("black")
player.shapesize(1,5) #높이, 너비 
player.up()
player.speed(0) #최대속도
player.goto(0,-270)

#먹이
food1 = t.Turtle()
food1.ht()
food1.shape("triangle")
food1.up()
food1.color("deeppink")
food1.speed(0)
food1.setheading(90)
food1.goto(random_pos())
food1.st()

food2 = t.Turtle()
food2.ht()
food2.shape("square")
food2.up()
food2.color("deeppink")
food2.speed(0)
food2.setheading(90)
food2.goto(random_pos())
food2.st()

food3 = t.Turtle()
food3.ht()
food3.shape("circle")
food3.up()
food3.color("deeppink")
food3.speed(0)
food3.setheading(90)
food3.goto(random_pos())
food3.st()

food4 = t.Turtle()
food4.ht()
food4.shape("triangle")
food4.up()
food4.color("deeppink")
food4.speed(0)
food4.setheading(90)
food4.goto(random_pos())
food4.st()

food5 = t.Turtle()
food5.ht()
food5.shape("square")
food5.up()
food5.color("deeppink")
food5.speed(0)
food5.setheading(90)
food5.goto(random_pos())
food5.st()

#볼
ball = t.Turtle()
ball.shape("circle")
ball.shapesize(1, 1)
ball.up()
ball.speed(0)
ball.color("white")

#키보드키로 작동
t.listen()
t.onkeypress(right, "Right") #첫글자는 대문자
t.onkeypress(left, "Left")

#변수
ball_xspeed = 5
ball_yspeed = 5
ball_speed = 5
game_on = True        #while문 사용하기 위해 변수 설정
Life = 3  #생명 변수 사용

#종료화면
캡처_gif = "images/캡처.gif"
t.addshape(캡처_gif)


#점수표시
t.up()
t.ht()
t.goto(0,300)
t.write(f"Life : {Life}", False, "center", ("cooper Black", 20)) #Life 중괄호 안에 표시, 터틀 움직이지 않게 하기위해 False 처리, 중앙정렬, 글자크기 20


while game_on:        #볼을 계속 움직이도록 하기 위해서 while문 사용
    new_x = ball.xcor() + ball_xspeed
    new_y = ball.ycor() + ball_yspeed
    ball.forward(ball_speed)
    ball.goto(new_x, new_y) #goto를 이용해 해당위치로 이동

    if ball.xcor() > 240 or ball.xcor() < -240:  #볼의 x좌표값이 240보다 크다면 반대방향으로 이동
        ball_xspeed *= -1 #5x-1=-5 오른쪽벽에 닿았을 때는 +5에서 -5로 바뀌고 왼쪽벽에 닿게 되면 -5에서 +5로
        
    if ball.ycor() >340:
        ball_yspeed *= -1  #위쪽벽에 닿았을 때 반대방향으로 이동

    if ball.ycor() < -340:
        Life -= 1   #볼이 아래에 닿게 되면 생명 -1, 기존 생명값 지운다음 업데이트 
        t.clear()
        t.write(f"Life : {Life}", False, "center", ("cooper Black  ", 20))
        time.sleep(0.5)  #0.5초 시간 딜레이 후 재시작 
        ball.goto(0,100)  #아래쪽에 닿았을 때는 볼을 떨어뜨린것이기 때문에 볼의 위치 초기화, 생명차감
        ball_yspeed *= -1 #볼이 아래쪽으로 떨어지는 것을 방지하기 위해 x,y 스피드에 -1씩 곱해서 위로 쏘아올려지도록 설정
        ball_xspeed *= -1

    if ball.distance(food1) < 20 :
        food1.goto(random_pos())
        ball_speed += 0.5
    if ball.distance(food2) < 20 :
        food2.goto(random_pos())
        ball_speed += 1
    if ball.distance(food3)<20 :
        food3.goto(random_pos())
        ball_speed -= 0.5
    if ball.distance(food4)<20 :
        food4.goto(random_pos())
        ball_speed += 1.5
    if ball.distance(food5)<20 :
       food4.goto(random_pos())
       ball_speed -= 1


    if Life == 0:
        game_on = False
        t.goto(0,0)
        t.write("Game Over", False, "center", ("cooper Black  ", 20))
        en= t.Turtle()
        en.up()
        en.goto(0,0)
        en.shape(캡처_gif)
        
        

#패들감지
    if player.distance(ball) < 50 and -260< ball.ycor()<-245 :
        ball_yspeed *= -1   #패들에 닿게 되면 반대방향으로 튕기도록

t.done()        

